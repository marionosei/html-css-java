# HTML assignment 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/marionosei/pen/abqXpMa](https://codepen.io/marionosei/pen/abqXpMa).

